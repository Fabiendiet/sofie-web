
<div class="row">
	<div class="col-xs-12">
		<div class="box">
			<div class="box-header">
				<div class="box-name">
					<i class="fa fa-usd"></i>
					<span>Liste des reparateurs</span>
				</div>
				<div class="box-icons">
					<a class="collapse-link">
						<i class="fa fa-chevron-up"></i>
					</a>
					<a class="expand-link">
						<i class="fa fa-expand"></i>
					</a>
					<a class="close-link">
						<i class="fa fa-times"></i>
					</a>
				</div>
				<div class="no-move"></div>
			</div>
			<div class="box-content no-padding">
				<table class="table table-bordered table-striped table-hover table-heading table-datatable" id="datatable-1">
					<thead>
						<tr>
							<th>#</th>
							<th>Nom et prénom</th>
							<th>N° d'appel</th>
							<th>Réparations effectuées</th>
							<th>Taux de réalisation</th>
							<th>Délai moyen de réparation</th>
							<th>Transfert de charge pour absence</th>
							<th>Prise de commande</th>
							<th>Avis de réparation reçus</th>
							<th>Palmares</th>
						</tr>
					</thead>
					<tbody>
					<!-- Start: list_row -->
						<tr>
							<td>1</td>
							<td>Carlos Slim Helu & family</td>
							<td>$73 B</td>
							<td>74</td>
							<td>telecom</td>
							<td>Mexico</td>
							<td>74</td>
							<td>telecom</td>
							<td>Mexico</td>
							<td>Mexico</td>
						</tr>
						<tr>
							<td>2</td>
							<td>Bill Gates</td>
							<td>$67 B</td>
							<td>58</td>
							<td>Microsoft</td>
							<td>United States</td>
							<td>74</td>
							<td>telecom</td>
							<td>Mexico</td>
							<td>Mexico</td>
						</tr>
						<tr>
							<td>3</td>
							<td>Amancio Ortega</td>
							<td>$57 B</td>
							<td>77</td>
							<td>Zara</td>
							<td>Spain</td>
							<td>74</td>
							<td>telecom</td>
							<td>Mexico</td>
							<td>Mexico</td>
						</tr>
						
						
					<!-- End: list_row -->
					</tbody>
					
				</table>
			</div>
		</div>
	</div>
</div>