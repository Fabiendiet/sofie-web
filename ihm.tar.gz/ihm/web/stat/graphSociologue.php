<?php 
$id = $_GET['id'];
?>	
<input type='hidden' name="id" id="id" value="<?php echo $id; ?>" >
		<div class="box-content">
			<div id="graph_agent" style="width: 700px; height: 400px; margin: 0 auto">
					
			</div>
					
		</div>

<script src="js/graphAgent.js"></script>