#!/bin/bash

cd /var/www/html/sofiev4/api/scripts/sofie_alert_script/
php sofie_alert_script.php
