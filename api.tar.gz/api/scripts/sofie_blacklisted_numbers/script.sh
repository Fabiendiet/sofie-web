#!/bin/bash

cd /etc/asterisk/misc/sofie/
/bin/sh batch-import-phonenumber-into-blacklist.sh &
