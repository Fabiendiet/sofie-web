<?php
/***
Fichier de configuration des URL des webservices de synchronisation SOFIE
***/
return array(
		//'logPath' => 
		'smsGatewayUrl' => "http://localhost/",
		'regionalSmsGatewayNumber' => array('1' => '07268570', '2' => '48093660', '3' => '072685730', '4' => '072685740', '5' => '072685750'),
		
);
