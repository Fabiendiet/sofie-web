<?php

return array(

	'nbOfLine' => 10,
	'TypeOfSite' => 'Regional',
	'RegionName' => 'KARA',
	'RegionId' => 2
);
